package com.bookAnalysis.model;

import com.bookAnalysis.enums.Sentiment;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.LocalDate;

@Data
@Document
@AllArgsConstructor
@NoArgsConstructor
public class Books {
    @Id
    private ObjectId id;
    @NonNull
    private String name;
    @NonNull
    private String price;
    private LocalDate date;
    private Sentiment sentiment;
}
