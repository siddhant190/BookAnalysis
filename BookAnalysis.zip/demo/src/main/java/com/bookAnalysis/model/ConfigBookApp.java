package com.bookAnalysis.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.mongodb.core.mapping.Document;

@Data
@Document(collection = "config_book_app")
@NoArgsConstructor
@AllArgsConstructor
public class ConfigBookApp {

    private String key;
    private String value;
}
