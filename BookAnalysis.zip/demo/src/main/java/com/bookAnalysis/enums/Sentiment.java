package com.bookAnalysis.enums;

public enum Sentiment {
    HAPPY,
    SAD,
    ANGRY,
    ANXIOUS;

}
