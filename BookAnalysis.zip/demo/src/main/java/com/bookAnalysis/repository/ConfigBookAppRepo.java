package com.bookAnalysis.repository;

import com.bookAnalysis.model.ConfigBookApp;
import org.bson.types.ObjectId;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ConfigBookAppRepo extends MongoRepository<ConfigBookApp, ObjectId> {
}
