package com.bookAnalysis.service;

import com.bookAnalysis.model.SentimentData;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.listener.ListenerExecutionFailedException;
import org.springframework.stereotype.Service;

@Service
public class SentimentConsumerService {

    @Autowired
    private EmailService emailService;

    @KafkaListener(topics = "weekly-sentiment", groupId = "weekly-sentiment-group")
    public void consume(SentimentData sentimentData) {
        try {
            System.out.println("Received Sentiment Data: " + sentimentData);
            sendMail(sentimentData);
        } catch (ListenerExecutionFailedException e) {
            System.err.println("Error processing message: " + e.getMessage());
        }
    }

    public void sendMail(SentimentData sentimentData){
        emailService.mailSender(sentimentData.getEmail(), "Book Analysis for last 7 days", sentimentData.getSentiment());
    }

}
