package com.bookAnalysis.service;

import com.bookAnalysis.model.Books;
import com.bookAnalysis.model.User;
import com.bookAnalysis.repository.BooksRepo;
import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Service
public class BooksService {

    @Autowired
    private BooksRepo booksRepo;

    @Autowired
    private UserService userService;

    @Transactional
    public void save(Books books, String username) {
        try {
            User user = userService.getByUsername(username);
            books.setDate(LocalDate.now());
            Books saved = booksRepo.save(books);
            user.getBooks().add(saved);
            userService.saveUser(user);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public void save(Books books) {
        booksRepo.save(books);
    }

    public List<Books> getAll() {
        return booksRepo.findAll();
    }

    public void deleteById(ObjectId id, String username) {
        User user = userService.getByUsername(username);
        user.getBooks().removeIf(x -> x.getId().equals(id));
        userService.saveUser(user);
        booksRepo.deleteById(id);
    }

    public Optional<Books> getById(ObjectId id) {
        return booksRepo.findById(id);
    }

}
