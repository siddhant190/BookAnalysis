package com.bookAnalysis.service;

import com.bookAnalysis.model.User;
import com.bookAnalysis.repository.UserRepo;
import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class UserService {

    @Autowired
    private UserRepo userRepo;

    @Autowired
    private PasswordEncoder passwordEncoder;

    public User saveNewUser(User user){
        user.setRole("USER");
        user.setPassword(passwordEncoder.encode(user.getPassword()));
        return userRepo.save(user);
    }

    public void saveUser(User user){
        userRepo.save(user);
    }

    public void deleteByUsername(String username){
        userRepo.deleteByUserName(username);
    }

    public User getByUsername(String username){
        return userRepo.findByUserName(username);
    }

    public Optional<User> getById(ObjectId id){
        return userRepo.findById(id);
    }

    public List<User> getAll(){
        return userRepo.findAll();
    }


}
