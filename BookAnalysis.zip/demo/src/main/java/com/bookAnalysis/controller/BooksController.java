package com.bookAnalysis.controller;

import com.bookAnalysis.model.Books;
import com.bookAnalysis.model.User;
import com.bookAnalysis.service.BooksService;
import com.bookAnalysis.service.UserService;
import lombok.extern.slf4j.Slf4j;
import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Slf4j
@RestController
@RequestMapping("/books")
public class BooksController {

    @Autowired
    private BooksService booksService;

    @Autowired
    private UserService userService;

    @PostMapping("/add-book")
    public ResponseEntity<?> addBook(@RequestBody Books books){
        try {
            Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
            booksService.save(books, authentication.getName());
            log.info("Book is added");
            return new ResponseEntity<>("Book is added", HttpStatus.CREATED);
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping("/get-books")
    public ResponseEntity<?> getAllBooksOfUser() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        User user = userService.getByUsername(authentication.getName());
        List<Books> booksList = user.getBooks();
        if (!booksList.isEmpty())
            return new ResponseEntity<>(booksList, HttpStatus.OK);

        return new ResponseEntity<>("No books", HttpStatus.NOT_FOUND);
    }

    @GetMapping("/id/{id}")
    public ResponseEntity<?> getBook(@PathVariable ObjectId id){
        Optional<Books> book = booksService.getById(id);
        if (book.isPresent()){
            log.info("Book is present");
            return new ResponseEntity<>(book.get(), HttpStatus.OK);
        }
        return new ResponseEntity<>("Book not found", HttpStatus.NOT_FOUND);
    }

    @PutMapping("/id/{username}/{id}")
    public ResponseEntity<?> updateBook(
            @PathVariable String username,
            @PathVariable ObjectId id,
            @RequestBody Books newBook
    ){
        Books oldBook = booksService.getById(id).orElse(null);
        if (oldBook != null){
            oldBook.setDate(LocalDate.now());
            oldBook.setName(!newBook.getName().isEmpty() ? newBook.getName() : oldBook.getName());
            oldBook.setPrice(!newBook.getPrice().isEmpty() ? newBook.getPrice() : oldBook.getPrice());
            booksService.save(oldBook);
            return new ResponseEntity<>("Book updated", HttpStatus.OK);
        }
        return new ResponseEntity<>("Book not found", HttpStatus.NOT_FOUND);
    }

    @DeleteMapping("/id/{username}/{id}")
    public ResponseEntity<?> deleteBook(@PathVariable ObjectId id, @PathVariable String username){
        Optional<Books> book = booksService.getById(id);
        if (book.isPresent()){
            booksService.deleteById(id,username);
            return new ResponseEntity<>("Book is Deleted",HttpStatus.NO_CONTENT);
        }
        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }
}
