package com.bookAnalysis.controller;

import com.bookAnalysis.apiResponse.WeatherResponse;
import com.bookAnalysis.cache.AppCache;
import com.bookAnalysis.model.User;
import com.bookAnalysis.service.UserService;
import com.bookAnalysis.service.WeatherService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@Slf4j
@RestController
public class UserController {

    @Autowired
    private UserService userService;
    @Autowired
    private WeatherService weatherService;
    @Autowired
    private AppCache appCache;

    @GetMapping
    public List<User> getAllUser(){
        return userService.getAll();
    }


    @PutMapping("/user/update-user")
    public ResponseEntity<?> updateUser(@RequestBody User newUser){
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        User oldUser =  userService.getByUsername(authentication.getName());
        oldUser.setUserName(newUser.getUserName());
        oldUser.setPassword(newUser.getPassword());
        userService.saveNewUser(oldUser);
        return new ResponseEntity<>(oldUser, HttpStatus.OK);
    }

//    @DeleteMapping("/username/{username}")
//    public ResponseEntity<?> deleteUser(@PathVariable String username){
//        User user =  userService.getByUsername(username);
//        if (user!= null){
//            userService.deleteByUsername(username);
//            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
//        }
//        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
//    }

    @GetMapping("/user/greeting")
    public ResponseEntity<?> greeting(){
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        WeatherResponse weatherResponse = weatherService.getWeather("Mumbai");
        String greeting = "";
        if (weatherResponse != null){
            greeting = ", Weather : "+weatherResponse.getCurrent().getTemperature();
        }

        return new ResponseEntity<>("Hi " + authentication.getName() + greeting, HttpStatus.OK);
    }

    @GetMapping("/user/clear-app-cache")
    public ResponseEntity<?> clearCache(){
        appCache.init();
        return new ResponseEntity<>("Cache is cleared ", HttpStatus.OK);
    }

}
