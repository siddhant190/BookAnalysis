package com.bookAnalysis.scheduler;

import com.bookAnalysis.cache.AppCache;
import com.bookAnalysis.enums.Sentiment;
import com.bookAnalysis.model.Books;
import com.bookAnalysis.model.SentimentData;
import com.bookAnalysis.model.User;
import com.bookAnalysis.repository.UserRepoImpl;
import com.bookAnalysis.service.EmailService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;



import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class UserScheduler {

    @Autowired
    private EmailService emailService;

    @Autowired
    private UserRepoImpl userRepo;

    @Autowired
    private AppCache appCache;

    @Autowired
    private KafkaTemplate<String, SentimentData> kafkaTemplate;


//    @Scheduled(cron = "0 0 9 * * SUN")
    public void fetchUserAndSendMail(){
        List<User> userForBA = userRepo.getUserForBA();
        for (User user : userForBA){
            List<Books> books = user.getBooks();
            List<Sentiment> sentimentList = books.stream().filter(x -> x.getDate().isAfter(LocalDate.now().minusDays(7))).map(Books::getSentiment).toList();
            HashMap<Sentiment,Integer> sentimentCounts = new HashMap<>();
            for (Sentiment sentiment : sentimentList) {
                sentimentCounts.put(sentiment, sentimentCounts.getOrDefault(sentiment, 0) + 1);
            }
            Sentiment mostFrequentSentiment = null;
            int maxCount = 0;
            for (Map.Entry<Sentiment, Integer> entry : sentimentCounts.entrySet()){
                if (entry.getValue() > maxCount){
                    maxCount = entry.getValue();
                    mostFrequentSentiment = entry.getKey();
                }
            }

            if (mostFrequentSentiment != null)
                try {
                    SentimentData sentimentData = SentimentData.builder().email(user.getEmail()).sentiment("Book Analysis for 7 days : "+mostFrequentSentiment).build();
                    kafkaTemplate.send("weekly-sentiment", sentimentData.getEmail(), sentimentData);
                } catch (Exception e) {
                    emailService.mailSender(user.getEmail(), "Book Analysis for 7 days", mostFrequentSentiment.toString());
                }
        }
    }


    @Scheduled(cron = "0 */10 * ? * *")
    public void clearAppcache(){
      appCache.init();
    }
}
