package com.bookAnalysis.contants;

public interface Placeholders {

    String apiKey = "API_KEY";
    String city = "CITY";
}
