package com.bookAnalysis.cache;

import com.bookAnalysis.model.ConfigBookApp;
import com.bookAnalysis.repository.ConfigBookAppRepo;
import jakarta.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.List;

@Component
public class AppCache {

    public enum ApiKeys{
        weather_api;
    }

    @Autowired
    private ConfigBookAppRepo configBookAppRepo;

    public HashMap<String, String> appCache;

    @PostConstruct
    public  void init(){
        appCache = new HashMap<>();
        List<ConfigBookApp> list = configBookAppRepo.findAll();
        for (ConfigBookApp configBookApp : list){
            appCache.put(configBookApp.getKey(),configBookApp.getValue());
        }
    }

}
