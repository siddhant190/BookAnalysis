package com.bookAnalysis.services;

import com.bookAnalysis.service.EmailService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmailServiceTest {

    @Autowired
    private EmailService emailService;

    @Test
    void setEmailService(){
        emailService.mailSender("chouhansidhantsingh945@gmail.com", "Hello Sid", "Hoe are you ?");
    }


}